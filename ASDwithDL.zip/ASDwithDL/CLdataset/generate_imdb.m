clear
clc

imgpath1 = ('D:\package\BM-CNN\dataset\CLdataset_0.6\train\');

di1 = dir(fullfile(imgpath1,'*.jpg'));
for k= 1:length(di1)
    I(:,:,:,k) = imread([imgpath1,di1(k).name]);
end

data1 = im2double(I);

for k= 1:length(di1)
   label1(1,k) = str2num(di1(k).name(7:7));
end
% ---------------------------------------------------------------------
imgpath2 = ('D:\package\BM-CNN\dataset\CLdataset_0.6\test\');
di2 = dir(fullfile(imgpath2,'*.jpg'));
for k= 1:length(di2)
    I2(:,:,:,k) = imread([imgpath2,di2(k).name]);
end

data2 = im2double(I2);
for k= 1:length(di2)
   label2(1,k) = str2num(di2(k).name(7:7));
end

set = [ones(1,numel(label1)) 3*ones(1,numel(label2))];
data = single(cat(4,data1,data2)); 
dataMean = mean(data1(:,:,:,:), 4);
dataMean = single(dataMean);
data = bsxfun(@minus, data, dataMean) ; 


images.data = data ;
images.data_mean = dataMean;
images.labels = cat(2, label1, label2) ; 
images.set = set ;
meta.sets = {'train', 'val', 'test'} ; 
meta.class = {'norm','anorm'};
save imdb.mat images meta
clear
clc
