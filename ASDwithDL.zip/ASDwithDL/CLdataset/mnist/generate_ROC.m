clear
clc
%% Test
run('D:\package\matlab2016b\matconvnet\matconvnet-1.0-beta25\matlab\vl_setupnn.m') ;
load('D:\package\BM-CNN\dataset\CLdataset\mnist\data\mnist-bnorm\net-epoch-20.mat') ;
mycifar_batch1_2_imdb = load('D:\package\BM-CNN\dataset\CLdataset\imdb.mat');

test_index = find(mycifar_batch1_2_imdb.images.set==3); 
test_index_norm = test_index(1:100); 
test_index_anorm = test_index(101:200);  
test_data_norm = mycifar_batch1_2_imdb.images.data(:,:,:,test_index_norm);  
test_data_anorm = mycifar_batch1_2_imdb.images.data(:,:,:,test_index_anorm);  
test_label_norm =mycifar_batch1_2_imdb.images.labels(test_index_norm);  
test_label_anorm =mycifar_batch1_2_imdb.images.labels(test_index_anorm); 

%net = vl_simplenn_tidy(net) ;
net.layers{1,end}.type = 'softmax';
p_f = 0.1:0.1:1.0;  %the probability of false alarm
%% Set the threshold
for i = 1:length(test_label_norm)
    %i
    im_ = test_data_norm(:,:,:,i);
    im_ = im_ - mycifar_batch1_2_imdb.images.data_mean;
    res = vl_simplenn(net, im_,[], [], ...
                      'accumulate', 0, ...
                      'mode', 'test', ...
                      'backPropDepth', Inf, ...
                      'sync', 0, ...
                      'cudnn', 1);
    scores = squeeze(gather(res(end).x)) ;
    %scores
    scores = scores(2)/scores(1);
    scores_norm(i) = scores;  
    [scores_norm_descend,scores_norm_index] = sort(scores_norm,2,'descend');
end
%% Get the ROC
for k = 1:length(p_f)
    gamma_1 = scores_norm_descend((k/10)*(length(scores_norm_descend)));%set the detection threshold according to the p_f

    for j = 1:length(test_label_anorm)
        %i
        im_ = test_data_anorm(:,:,:,j);
        im_ = im_ - mycifar_batch1_2_imdb.images.data_mean;
        res = vl_simplenn(net, im_,[], [], ...
                          'accumulate', 0, ...
                          'mode', 'test', ...
                          'backPropDepth', Inf, ...
                          'sync', 0, ...
                          'cudnn', 1);
        scores = squeeze(gather(res(end).x)) ;
        scores = scores(2)/scores(1);
        if scores >= gamma_1
            pre(j) = 2;
        else
            pre(j) = 1;
        end
    end

    accurcy = length(find(pre==test_label_anorm))/length(test_label_anorm);
    p_d(k) = accurcy; %the probability of detection
end
%% polt ROC
 plot(p_f,p_d,'-sr')
axis([0.1,1,0.1,1]) 
set(gca,'XTick',(0.1:0.1:1.0))
set(gca,'YTick',(0.1:0.1:1.0))
legend('BM-CNN')
xlabel('Probability of false alarm')
ylabel('probability of detection')
grid on
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
save p_d p_d
clear
clc