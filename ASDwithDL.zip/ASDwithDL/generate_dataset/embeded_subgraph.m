function [adj degree_average] = embeded_subgraph(adj_back,index_embeded,ps,n)

% embed the foreground random graph into background random graph
% refereence:
% (1) a spectral framework for anomalous subgraph detection, 2015, TSP


% adj_back, the adjacent matrix of background random graph
% index_embeded, the indices of embeded vertices
% ps, the edges probability between the vertices of foreground random graph
% n, the total number of the embeded vertices

index_whole = index_embeded;
fore_deg = 0;
adj = adj_back;
for i=1:n-1
    index1 = index_whole(i);
    for j=i+1:n
        index2 = index_whole(j);
        if rand<=ps 
            ad_v = 1; 
            adj(index1,index2) = adj(index1,index2)|ad_v; 
            adj(index2,index1) = adj(index2,index1)|ad_v; % symmetric matrix
            fore_deg = fore_deg + 1;
        end % no self-loops
    end
end

degree_average = 2*fore_deg/n; % average degree of foreground random graph
Pe = sum(adj,1); 
Pe_sub = Pe(index_whole);