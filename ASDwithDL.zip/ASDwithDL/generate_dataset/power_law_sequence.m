function sequence = power_law_sequence(N,xmin,alpha)

% generate the degree sequence, meeted with power law distribution
% refer to:  Power-law Distributions in Empirical Data,2007, www.santafe.edu

% N, the number of points or vertices
% Xmin, the lower limit of sequence
% alpha, the parameter of power law distribution
x = xmin.*(1-rand(N,1)).^(-1/(alpha-1));
sequence = sort(x,1);
sequence = rot90(sequence,2);