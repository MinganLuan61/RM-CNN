function sequence = chung_lu_sequence(base_pro,N)

% generate the degree sequence, meeted with Chung_lu distribution
% the degree sequence meets with R-MAT method
% the degree sequence is with arbitrary given degree sequence.
% Refer to: a spectral framework for anomalous subgraph detection, 2015,
% TSP


% N, the number of points or vertices
% base_pro, a base probability matrix

A = base_pro;
for k=1:log2(N)-1
    A = kron(A,base_pro);
end
t = 12*N; % the total number of iterations is t
for i = 1:N
    for j = 1:N
        P(i,j) = 1-(1-A(i,j))^t;
    end
end
w = sum(P,1); % the expected degree sequence of the Chung-Lu random graph
sequence = sort(w,2);
sequence = rot90(sequence,2);