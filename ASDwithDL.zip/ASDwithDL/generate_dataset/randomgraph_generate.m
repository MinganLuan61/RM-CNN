% Title: Anomaly Detection based on subgraph seraching?

% Aim to generate three types of data for simulations; Erdos-Renyi random
% graph, Chung-Lu random graph and Power-Law random graph.

% References:
% (1) Power-law Distributions in Empirical Data,2007, www.santafe.edu for
% power-law random graph
% (2) A spectral framework for anomalous subgraph detection, 2015, TSP for
% Chung-Lu random graph
clc
close all
clear all

% generate the degree sequence meeted with power law distribution
% refer to:  Power-law Distributions in Empirical Data,2007, www.santafe.edu
N = 1024;
xmin  = 8;
alpha = 4.0;
sequence_pl = power_law_sequence(N,xmin,alpha);
degree_avepl = sum(sequence_pl)/N;
P_pl = sequence_pl*sequence_pl'/sum(sequence_pl); % to assure that all the edge probability are smaller than 1
figure (1)
plot(1:N,sequence_pl','r-o','LineWidth',2);
xlabel('label of vertices')
ylabel('degree of vertices')
grid on

base_pro = [0.3 0.1;0.1 0.5]; % a base probability matrix
N = 1024; % the total number of vertices
sequence_cl = chung_lu_sequence(base_pro,N);
sequence_cl = sequence_cl';
degree_avecl = sum(sequence_cl)/N;
sequence_cl = (degree_avepl/degree_avecl)*sequence_cl;
degree_avecl = sum(sequence_cl)/N;
P_cl = sequence_cl*sequence_cl'/sum(sequence_cl);  % to assure that all the edge probability are smaller than 1

figure (2)
plot(1:N,sequence_cl','r-o','LineWidth',2);
xlabel('label of vertices')
ylabel('degree of vertices')
grid on

% generate the degree sequence meeted with  Erdos-Renyi random graph
sequence_er = degree_avepl*ones(N,1);
P_er = sequence_er*sequence_er'/sum(sequence_er);
degree_aveer = sum(sum(P_er))/N;

degree_average = degree_aveer;

save sequence sequence_pl  sequence_cl  sequence_er  degree_average;
clc
clear
load 'sequence'
clc