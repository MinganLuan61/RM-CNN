%generate norm dateset.
%type:.png image
clc
close all
clear all

%Load the degree sequences of CL random graph
load 'sequence'
N = length(sequence_cl);
n_set = 15;
ps = 0.5;
mc = 1000;%generate the number of images
index = 1:N;
indc = size(index); % the size of embedded set of random graph
ind_c = indc(2);
index_sub_set = zeros(length(n_set),max(n_set));
for st = 1:length(n_set)
    n = n_set(st);
    ind_1 = randperm(ind_c); % uniformly select the embedded vertices from the certain set
    index_sub = index(ind_1(1:n)); % the indices of selected vertices
    index_sub = sort(index_sub);
    index_sub_set(st,1:n) = index_sub;
end
for st = 1 : length(n_set)
    n = n_set(st); % the total number of the subgraph vertices
    index_sub = index_sub_set(st,1:n);
    for mm = 1:mc
        % to generate adjacent matrices  of background random graphs (noise
        %matrices or noise compoents) corresponding chung-Lu
        adj_cl = zeros(N,N);
        Pc_cl = sequence_cl*sequence_cl'/sum(sequence_cl);
        for i = 1:N
            for j = i:N
                var_mdedium = rand(1);
                if var_mdedium<=Pc_cl(i,j);adj_cl(i,j)=1; adj_cl(j,i)=1;end
            end
        end
        index_whole = index_sub; % the indices of the vertices embeded by anomalous subgraph
        [adj_cl degree_cl] = embeded_subgraph(adj_cl,index_whole,ps,n);
        % serach the starting vertices or starting points
        sequence_observed_cl = sum(adj_cl,1);
        Pe_cl = sequence_observed_cl;
        
        %compute the residual matrices
        adj_res_cl = adj_cl - Pc_cl; % Pc_xx, the expected adjacent matrix of background random graph; residual matrix
        
        %compute variances of the degree sequences for three random graph
        P_var_cl = Pc_cl .* (ones(N,N)-Pc_cl);
        p_var_cl = sum(P_var_cl,1);
        
        %compute the resdiual degree vector normalized with variances of vertices
        degree_res_cl = (Pe_cl-sequence_cl')./sqrt(p_var_cl);
        degree_res_cl1 = (sequence_cl'-Pe_cl).^2./(p_var_cl);
        degree_res_cl2 = (Pe_cl-sequence_cl');
        [value_dcl1,index_dcl1] = sort(degree_res_cl1,2,'descend');
        [value_dcl,index_dcl] = sort(degree_res_cl,2,'descend');
        [value_dcl2,index_dcl2] = sort(degree_res_cl2,2,'descend');
        k = 32; % the number of candidated vertices, rude searching
        index_ccl1 = index_dcl1(1:k);
        index_ccl2 = index_dcl2(1:k);
        value_ccl = value_dcl(1:k);
        index_ccl = index_dcl(1:k);
        residual_matrix = adj_cl - (sequence_observed_cl' *sequence_observed_cl)/sum(sequence_observed_cl);
        input_matrix =  residual_matrix(index_ccl,index_ccl);
        imwrite(input_matrix,['C:\Users\57696\Desktop\11\',strcat('label_',int2str(2),'_',int2str(mm)),'.jpg']);
        intersect(index_sub,index_ccl)
        intersect(index_sub,index_ccl1)
        intersect(index_sub,index_ccl2)
        
        
    end
end